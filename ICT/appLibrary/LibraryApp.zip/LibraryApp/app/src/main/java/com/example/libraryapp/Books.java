package com.example.libraryapp;


import com.google.gson.annotations.SerializedName;

public class Books {
    @SerializedName("b_id") private String bookID;
    @SerializedName("b_name") private String bookName;
    @SerializedName("b_writer") private String bookWriter;
    @SerializedName("b_category") private Integer bookCategory;
    @SerializedName("b_price") private Integer bookPrice;

    public String getBookID() {
        return "รหัสหนังสือ : " + bookID;
    }

    public String getBookName() {
        return "ชื่อหนังสือ : " + bookName;
    }

    public String getBookWriter() {
        return "นักเขียน : " + bookWriter;
    }

    public String getBookCategory() {
        String type = "";
        if (bookCategory == 1) {
            type = "วิชาการ";
        }
        else if (bookCategory == 2) {
            type = "วรรณกรรม";
        }
        else if (bookCategory == 3) {
            type = "เบ็ดเตล็ด";
        }

        return "หมวดหมู่ : " + type;
    }

    public String getBookPrice() {
        return "ราคา : " + bookPrice.toString() + " บาท";
    }
}
