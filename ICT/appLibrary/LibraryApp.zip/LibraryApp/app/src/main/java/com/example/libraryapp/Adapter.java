package com.example.libraryapp;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {

    private List<Books> books;
    private Context context;

    public Adapter(List<Books> books, Context context) {
        this.books = books;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        holder.bookID.setText(books.get(position).getBookID());
        holder.bookName.setText(books.get(position).getBookName());
        holder.bookWriter.setText(books.get(position).getBookWriter());
        holder.bookCategory.setText(books.get(position).getBookCategory());
        holder.bookPrice.setText(books.get(position).getBookPrice());

    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView bookID, bookName, bookWriter, bookCategory, bookPrice;

        public MyViewHolder(View itemView) {
            super(itemView);
            bookID = itemView.findViewById(R.id.textView_b_id);
            bookName = itemView.findViewById(R.id.textView_b_name);
            bookWriter = itemView.findViewById(R.id.textView_b_writer);
            bookCategory = itemView.findViewById(R.id.textView_b_category);
            bookPrice = itemView.findViewById(R.id.textView_b_price);

        }
    }

}
