package com.example.libraryapp;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("getBooks.php")
    Call < List<Books> > getBooks ( @Query("key") String keyword );

    @GET("getBooks.php")
    Call < List<Books> > filterBooks ( @Query("key") String keyword, @Query("type") String optionType);
}
