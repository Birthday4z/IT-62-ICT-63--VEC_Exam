package com.example.libraryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private List<Books> books;
    private Adapter adapter;
    private ApiInterface apiInterface;
    private SearchView searchView;
    private RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        fetchBooks(""); //กรณีไม่ใส่ keyword

        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                fetchBooks(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                // หาประเภทที่ผู้ใช้ค้นหา กรณีเปลี่ยน keyword
                // สร้างตัวแปรเก็บประเภทการค้นหา 1 = ทั้งหมด 2 = รหัสหนังสือ 3 = ชื่อหนังสือ 4 = ผู้เขียน
                radioGroup = findViewById(R.id.radioGroup_type);
                if(radioGroup.getCheckedRadioButtonId() == findViewById(R.id.radioButton_All).getId()) { // ทั้งหมด
                    filterBooks(s, "1");
//                    Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : ทั้งหมด", Toast.LENGTH_SHORT).show(); // LOG Debug
                }
                else if(radioGroup.getCheckedRadioButtonId() == findViewById(R.id.radioButton_bookID).getId()) { // รหัสหนังสือ
                    filterBooks(s, "2");
//                    Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : รหัสหนังสือ", Toast.LENGTH_SHORT).show(); // LOG Debug
                }
                else if(radioGroup.getCheckedRadioButtonId() == findViewById(R.id.radioButton_bookName).getId()) { // ชื่อหนังสือ
                    filterBooks(s, "3");
//                    Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : ชื่อหนังสือ", Toast.LENGTH_SHORT).show(); // LOG Debug
                }
                else if(radioGroup.getCheckedRadioButtonId() == findViewById(R.id.radioButton_bookWriter).getId()) { // นักเขียน
                    filterBooks(s, "4");
//                    Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : นักเขียน", Toast.LENGTH_SHORT).show(); // LOG Debug
                }


                // หาประเภทที่ผู้ใช้ค้นหา กรณีจิ้มประเภท
                radioGroup = findViewById(R.id.radioGroup_type);
                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

                    public void onCheckedChanged(RadioGroup group, int checkedid) {
                        switch(checkedid) {

                            case R.id.radioButton_All: // ทั้งหมด
                                filterBooks(s, "1");
//                                Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : ทั้งหมด", Toast.LENGTH_SHORT).show(); // LOG Debug
                                break;
                            case R.id.radioButton_bookID: // รหัสหนังสือ
                                filterBooks(s, "2");
//                                Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : รหัสหนังสือ", Toast.LENGTH_SHORT).show(); // LOG Debug
                                break;
                            case R.id.radioButton_bookName: // ชื่อหนังสือ
                                filterBooks(s, "3");
//                                Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : ชื่อหนังสือ", Toast.LENGTH_SHORT).show(); // LOG Debug
                                break;
                            case R.id.radioButton_bookWriter: // ผู้เขียน
                                filterBooks(s, "4");
//                                Toast.makeText(MainActivity.this, "Search : \"" + s + "\"  Option : ผู้เขียน", Toast.LENGTH_SHORT).show(); // LOG Debug
                                break;
                        }
                    }
                });
                return false;
            }
        });
    }

    public void notFoundItem() {

    }

    public void fetchBooks(String key) { // ดึงข้อมูลหนังสือจาก keyword
        apiInterface = APIClient.getAPIClient().create(ApiInterface.class);
        Call<List<Books>> call = apiInterface.getBooks(key);

        call.enqueue(new Callback<List<Books>>() {
            @Override
            public void onResponse(Call<List<Books>> call, Response<List<Books>> response) {
                books = response.body();
                adapter = new Adapter(books, MainActivity.this);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<List<Books>> call, Throwable t) {
                // ถ้าเกิดข้อผิดพลาด
                Toast.makeText(MainActivity.this, "Error on: " + t.toString(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void filterBooks(String key, String optionType) { // ดึงข้อมูลหนังสือจาก keyword และ ประเภท
        apiInterface = APIClient.getAPIClient().create(ApiInterface.class);
        Call<List<Books>> call = apiInterface.filterBooks(key, optionType);

        call.enqueue(new Callback<List<Books>>() {
            @Override
            public void onResponse(Call<List<Books>> call, Response<List<Books>> response) {
                books = response.body();
                adapter = new Adapter(books, MainActivity.this);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<List<Books>> call, Throwable t) {
                // ถ้าเกิดข้อผิดพลาด
                Toast.makeText(MainActivity.this, "Error on: " + t, Toast.LENGTH_LONG).show();
            }
        });
    }



}